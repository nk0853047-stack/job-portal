
from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os

app = Flask(__name__)
app.secret_key = "internship-portal-demo-key"
DB = "database.db"
UPLOAD_DIR = os.path.join("uploads", "resumes")
os.makedirs(UPLOAD_DIR, exist_ok=True)

JOBS = [
    (1, "Frontend Developer Intern", "TechNova Labs", "Remote", "₹8,000/mo", "3 Months", "HTML, CSS, JavaScript"),
    (2, "Python Developer Intern", "CodeCraft", "Bengaluru", "₹12,000/mo", "6 Months", "Python, Flask, SQL"),
    (3, "UI/UX Design Intern", "PixelWorks", "Remote", "₹10,000/mo", "3 Months", "Figma, UI Design"),
    (4, "Data Analyst Intern", "InsightHub", "Delhi", "₹15,000/mo", "6 Months", "Python, Excel, SQL"),
    (5, "Digital Marketing Intern", "GrowSphere", "Mumbai", "₹7,000/mo", "3 Months", "SEO, Social Media"),
    (6, "GIS Developer Intern", "GeoVision", "Hyderabad", "₹14,000/mo", "6 Months", "GIS, JavaScript, Python")
]

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""CREATE TABLE IF NOT EXISTS applications(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER, name TEXT, email TEXT, resume TEXT
    )""")
    conn.commit()
    conn.close()

@app.route("/")
def home():
    return render_template("index.html", jobs=JOBS)

@app.route("/jobs")
def jobs():
    q = request.args.get("q", "").lower()
    location = request.args.get("location", "").lower()
    filtered = [j for j in JOBS if (not q or q in j[1].lower() or q in j[6].lower() or q in j[2].lower())
                and (not location or location in j[3].lower())]
    return render_template("jobs.html", jobs=filtered, q=q, location=location)

@app.route("/job/<int:job_id>")
def job_details(job_id):
    job = next((j for j in JOBS if j[0] == job_id), None)
    if not job:
        return "Job not found", 404
    return render_template("job-details.html", job=job)

@app.route("/apply/<int:job_id>", methods=["GET", "POST"])
def apply(job_id):
    job = next((j for j in JOBS if j[0] == job_id), None)
    if not job:
        return "Job not found", 404
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        resume = request.files.get("resume")
        filename = ""
        if resume and resume.filename:
            safe_name = os.path.basename(resume.filename)
            filename = safe_name
            resume.save(os.path.join(UPLOAD_DIR, safe_name))
        conn = get_db()
        conn.execute("INSERT INTO applications(job_id,name,email,resume) VALUES(?,?,?,?)",
                     (job_id, name, email, filename))
        conn.commit()
        conn.close()
        flash("Application submitted successfully! 🎉")
        return redirect(url_for("home"))
    return render_template("apply.html", job=job)

@app.route("/dashboard")
def dashboard():
    conn = get_db()
    applications = conn.execute("SELECT * FROM applications ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("dashboard.html", applications=applications, jobs=JOBS)

@app.route("/recruiter")
def recruiter():
    return render_template("recruiter.html", jobs=JOBS)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
